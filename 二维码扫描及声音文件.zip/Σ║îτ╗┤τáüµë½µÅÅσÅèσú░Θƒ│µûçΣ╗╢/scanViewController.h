//
//  scanViewController.h
//  EasyToLearnShop
//
//  Created by jingxue li on 17/4/12.
//  Copyright © 2017年 yiyiche. All rights reserved.
//

#import "ViewController.h"
@protocol GetPromptUpdateResultDelegate <NSObject>

-(void)returnsResultSuccess:(NSString*)result code:(NSString*)code;

@end
@interface scanViewController : XYCRootViewController
@property (assign,nonatomic,readwrite)id <GetPromptUpdateResultDelegate>delegate;
@property NSString *numberString;
@end
