//
//  scanViewController.m
//  EasyToLearnShop
//
//  Created by jingxue li on 17/4/12.
//  Copyright © 2017年 yiyiche. All rights reserved.
//

#import "scanViewController.h"
#import "QRCodeReaderView.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>

#define DeviceMaxHeight ([UIScreen mainScreen].bounds.size.height)
#define DeviceMaxWidth ([UIScreen mainScreen].bounds.size.width)
#define widthRate DeviceMaxWidth/320
#define IOS8 ([[UIDevice currentDevice].systemVersion intValue] >= 8 ? YES : NO)

@interface scanViewController ()<QRCodeReaderViewDelegate,AVCaptureMetadataOutputObjectsDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIAlertViewDelegate>{
    QRCodeReaderView * readview;//二维码扫描对象
    BOOL isFirst;//第一次进入该页面
    BOOL isPush;//跳转到下一级页面
    long keepexit;
}
@property (weak, nonatomic) IBOutlet UIView *RootView;
@property (strong, nonatomic) CIDetector *detector;
@end

@implementation scanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"扫描";
    _RootView.backgroundColor = NAVGATION_VIEW_COLOR
    isFirst = YES;
    isPush  = NO;
    [self InitScan];
}
#pragma mark - 返回
- (IBAction)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark 初始化扫描
- (void)InitScan{
    if (readview) {
        [readview removeFromSuperview];
        readview = nil;
    }
    readview = [[QRCodeReaderView alloc]initWithFrame:CGRectMake(0, 64, DeviceMaxWidth, DeviceMaxHeight-64)];
    readview.is_AnmotionFinished = YES;
    readview.backgroundColor = [UIColor clearColor];
    readview.delegate = self;
    readview.alpha = 0;
    [self.view addSubview:readview];
    [UIView animateWithDuration:0.5 animations:^{
        readview.alpha = 1;
    }completion:^(BOOL finished) {
    }];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    if (!image){
        image = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    readview.is_Anmotion = YES;
    NSArray *features = [self.detector featuresInImage:[CIImage imageWithCGImage:image.CGImage]];
    if (features.count >=1) {
        [picker dismissViewControllerAnimated:YES completion:^{
            [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
            CIQRCodeFeature *feature = [features objectAtIndex:0];
            NSString *scannedResult = feature.messageString;
            //播放扫描二维码的声音
            SystemSoundID soundID;
            NSString *strSoundFile = [[NSBundle mainBundle] pathForResource:@"noticeMusic" ofType:@"wav"];
            AudioServicesCreateSystemSoundID((__bridge CFURLRef)[NSURL fileURLWithPath:strSoundFile],&soundID);
            AudioServicesPlaySystemSound(soundID);
            [self accordingQcode:scannedResult];
        }];
    }else{
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"该图片没有包含一个二维码！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [picker dismissViewControllerAnimated:YES completion:^{
            [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
            readview.is_Anmotion = NO;
            [readview start];
        }];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:^{
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    }];
}

#pragma mark -QRCodeReaderViewDelegate
- (void)readerScanResult:(NSString *)result{
    readview.is_Anmotion = YES;
    [readview stop];
    //播放扫描二维码的声音
    SystemSoundID soundID;
    NSString *strSoundFile = [[NSBundle mainBundle] pathForResource:@"noticeMusic" ofType:@"wav"];
    AudioServicesCreateSystemSoundID((__bridge CFURLRef)[NSURL fileURLWithPath:strSoundFile],&soundID);
    AudioServicesPlaySystemSound(soundID);
    [self accordingQcode:result];
    [self performSelector:@selector(reStartScan) withObject:nil afterDelay:1.5];
}

#pragma mark - 扫描结果处理
- (void)accordingQcode:(NSString *)str{
    if ([JudgeIDAndBankCard isEmptyOrNull:_numberString]==NO) {
        NSDictionary *dic = @{@"agent_shop_number":_numberString,
                              @"agent_user_phone":str};
        NSString *urlString = [NSString stringWithFormat:@"%@%@",SERVER_URL,@"/mg/agentinfo/updateusergyshop.do"];
        [NetHttpRequst NetRequestPOSTWithRequestURL:urlString
                                      WithParameter:dic
                               WithReturnValeuBlock:^(id returnValue) {
               if([JudgeIDAndBankCard judgeRequstResoutsNotSuccess:returnValue]==YES){
                   if ([_delegate respondsToSelector:@selector(returnsResultSuccess: code:)]) {
                       [_delegate returnsResultSuccess:returnValue[@"content"] code:@"0"];
                   }
                   [self.navigationController popViewControllerAnimated:YES];
               }else{
                   if ([_delegate respondsToSelector:@selector(returnsResultSuccess: code:)]) {
                       [_delegate returnsResultSuccess:returnValue[@"content"] code:@"1"];
                   }
                   [self.navigationController popViewControllerAnimated:YES];
               }
        } WithErrorCodeBlock:^(id errorCode) {
           
        } WithFailureBlock:^{
           
        }];
    }
}

- (void)reStartScan{
    readview.is_Anmotion = NO;
    if (readview.is_AnmotionFinished) {
        [readview loopDrawLine];
    }
    [readview start];
}

#pragma mark - view
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
    self.tabBarController.tabBar.hidden = YES;
    if (isFirst || isPush) {
        if (readview) {
            [self reStartScan];
        }
    }
//    [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"JUDGE_NOT_ORDER"];
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    if (readview) {
        [readview stop];
        readview.is_Anmotion = YES;
    }
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (isFirst) {
        isFirst = NO;
    }
    if (isPush) {
        isPush = NO;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
